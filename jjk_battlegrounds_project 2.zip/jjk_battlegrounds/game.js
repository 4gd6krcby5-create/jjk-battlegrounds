(() => {
  "use strict";
  const characters = [
    {id:"yuji",name:"YUJI ITADORI",role:"Close-range brawler",initial:"悠",hp:120,damage:13,heavy:23,ability:"DIVERGENT FIST",abilityCost:25,abilityDamage:31,ultimate:"BLACK FLASH RUSH",domain:"INNER RESOLVE",domainText:"A focused domain that empowers every strike.",color:"#ff5574"},
    {id:"gojo",name:"SATORU GOJO",role:"Limitless technique",initial:"悟",hp:105,damage:11,heavy:20,ability:"BLUE: CURSED PULL",abilityCost:30,abilityDamage:35,ultimate:"HOLLOW PURPLE",domain:"UNLIMITED VOID",domainText:"Overwhelm the opponent with an information storm.",color:"#63d9ef"},
    {id:"megumi",name:"MEGUMI FUSHIGURO",role:"Shikigami user",initial:"伏",hp:110,damage:12,heavy:19,ability:"DIVINE DOG",abilityCost:25,abilityDamage:29,ultimate:"CHIMERA SHADOW",domain:"CHIMERA SHADOW GARDEN",domainText:"A shadow field that strengthens your next techniques.",color:"#a78bfa"},
    {id:"todo",name:"AOI TODO",role:"Tactical powerhouse",initial:"東",hp:130,damage:15,heavy:25,ability:"BOOGIE WOOGIE",abilityCost:20,abilityDamage:27,ultimate:"BESTO FRIENDO",domain:"BROTHERHOOD",domainText:"A battle rhythm that powers up your attacks.",color:"#f3b85e"}
  ];
  const $ = id => document.getElementById(id);
  const state = {character:characters[0],playerHp:120,enemyHp:100,energy:0,ult:0,domainTurns:0,locked:false,round:1,sound:false};
  const maxEnemyHp = 100;
  let enemyTimer = null;
  let audioCtx = null;

  function renderCharacters(){
    $("characterGrid").innerHTML = characters.map(c => `<button class="character ${c.id===state.character.id?"active":""}" data-id="${c.id}"><div class="char-avatar">${c.initial}</div><strong>${c.name}</strong><small>${c.role}</small></button>`).join("");
    document.querySelectorAll(".character").forEach(btn => btn.addEventListener("click",()=>selectCharacter(btn.dataset.id)));
  }
  function selectCharacter(id){
    if(state.locked)return;
    const c=characters.find(x=>x.id===id); if(!c)return;
    state.character=c;state.playerHp=c.hp;state.energy=0;state.ult=0;state.domainTurns=0;
    $("playerName").textContent=c.name;$("domainLabel").textContent=c.domain;$("domainDescription").textContent=c.domainText;
    $("abilityLabel").textContent=c.ability;$("abilityCost").textContent=c.abilityCost+" energy";$("ultimateLabel").textContent=c.ultimate;
    $("playerFighter").style.filter=`drop-shadow(0 0 12px ${c.color})`;
    $("arenaMessage").textContent=c.name+" ENTERS THE ARENA";
    renderCharacters();update();
  }
  function update(){
    const c=state.character;
    $("playerHealth").style.width=Math.max(0,state.playerHp/c.hp*100)+"%";
    $("enemyHealth").style.width=Math.max(0,state.enemyHp/maxEnemyHp*100)+"%";
    $("playerHealthText").textContent=`${Math.ceil(state.playerHp)} / ${c.hp}`;
    $("enemyHealthText").textContent=`${Math.ceil(state.enemyHp)} / ${maxEnemyHp}`;
    $("energyFill").style.width=state.energy+"%";$("energyText").textContent=state.energy+"%";
    $("ultFill").style.width=state.ult+"%";$("ultText").textContent=state.ult+"%";
    $("domainBtn").disabled=state.ult<100||state.locked;
    $("domainBtn").innerHTML=state.ult>=100?'DOMAIN <span>READY</span>':'DOMAIN <span>LOCKED</span>';
    $("attackBtn").disabled=state.locked;$("heavyBtn").disabled=state.locked;
    $("abilityBtn").disabled=state.locked||state.energy<c.abilityCost;
    $("ultimateBtn").disabled=state.locked||state.ult<100;
    $("roundLabel").textContent="ROUND "+String(state.round).padStart(2,"0");
  }
  function sound(frequency=180,duration=.08){
    if(!state.sound)return;
    try{audioCtx=audioCtx||new(window.AudioContext||window.webkitAudioContext)();const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.frequency.value=frequency;o.type="sawtooth";g.gain.setValueAtTime(.045,audioCtx.currentTime);g.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+duration);o.connect(g);g.connect(audioCtx.destination);o.start();o.stop(audioCtx.currentTime+duration)}catch(e){}
  }
  function message(text){$("arenaMessage").textContent=text}
  function flash(){const el=$("impact");el.classList.remove("flash");void el.offsetWidth;el.classList.add("flash")}
  function animateEnemy(){const e=$("enemyFighter");e.style.transform="translateX(16px) rotate(7deg)";setTimeout(()=>e.style.transform="",180)}
  function playerAction(kind){
    if(state.locked||state.enemyHp<=0||state.playerHp<=0)return;
    const c=state.character;let damage=0,gain=0;
    if(kind==="strike"){damage=c.damage;gain=13;message("CURSED ENERGY STRIKE!");sound(190)}
    if(kind==="heavy"){damage=c.heavy;gain=19;message("HEAVY IMPACT!");sound(125,.12)}
    if(kind==="ability"){
      if(state.energy<c.abilityCost)return;
      state.energy-=c.abilityCost;damage=c.abilityDamage;gain=10;message(c.ability+"!");sound(270,.16);
    }
    if(kind==="ultimate"){
      if(state.ult<100)return;
      state.ult=0;damage=54;gain=0;message(c.ultimate+"!!");flash();sound(390,.3);
    }
    if(state.domainTurns>0){damage=Math.round(damage*1.35);state.domainTurns--}
    state.enemyHp=Math.max(0,state.enemyHp-damage);
    state.energy=Math.min(100,state.energy+gain);
    state.ult=Math.min(100,state.ult+Math.round(damage*.9));
    animateEnemy();flash();update();
    if(state.enemyHp<=0){win();return}
    scheduleEnemy();
  }
  function scheduleEnemy(){
    clearTimeout(enemyTimer);enemyTimer=setTimeout(()=>{
      if(state.locked)return;
      const dmg=state.domainTurns>0?7:10+Math.floor(Math.random()*5);
      state.playerHp=Math.max(0,state.playerHp-dmg);message("OPPONENT COUNTERATTACK: -"+dmg+" HP");sound(90,.1);update();
      if(state.playerHp<=0)lose();
    },750);
  }
  function activateDomain(){
    if(state.ult<100||state.locked)return;
    state.ult=0;state.domainTurns=3;
    $("domainName").textContent=state.character.domain;$("domainOverlay").classList.add("active");
    message("DOMAIN EXPANSION ACTIVATED");sound(520,.35);update();
    setTimeout(()=>$("domainOverlay").classList.remove("active"),1700);
  }
  function win(){state.locked=true;message("VICTORY — CURSE EXORCISED");$("enemyFighter").style.opacity=".25";$("arenaMessage").style.color="#8af0ba";update()}
  function lose(){state.locked=true;message("DEFEAT — TRY AGAIN");$("playerFighter").style.opacity=".35";update()}
  function restart(){
    clearTimeout(enemyTimer);state.round++;state.playerHp=state.character.hp;state.enemyHp=maxEnemyHp;state.energy=0;state.ult=0;state.domainTurns=0;state.locked=false;
    $("playerFighter").style.opacity="1";$("enemyFighter").style.opacity="1";$("arenaMessage").style.color="";$("domainOverlay").classList.remove("active");message("FIGHT!");update();
  }
  $("attackBtn").addEventListener("click",()=>playerAction("strike"));
  $("heavyBtn").addEventListener("click",()=>playerAction("heavy"));
  $("abilityBtn").addEventListener("click",()=>playerAction("ability"));
  $("ultimateBtn").addEventListener("click",()=>playerAction("ultimate"));
  $("domainBtn").addEventListener("click",activateDomain);
  $("restartBtn").addEventListener("click",restart);
  $("soundBtn").addEventListener("click",()=>{state.sound=!state.sound;$("soundBtn").textContent="♫ SOUND: "+(state.sound?"ON":"OFF");sound(330)});
  document.addEventListener("keydown",e=>{if(e.repeat||/INPUT|TEXTAREA/.test(document.activeElement.tagName))return;const map={"1":"strike","2":"heavy","3":"ability","4":"ultimate"};if(map[e.key])playerAction(map[e.key])});
  renderCharacters();update();message("CHOOSE YOUR SORCERER");
})();