# JJK Battlegrounds — Mobile Web Prototype

A small, responsive, single-player arena combat prototype built with vanilla HTML, CSS and JavaScript. It uses original UI/placeholder fighter art and is an unofficial fan-made project.

## Requirements
- Node.js 18+ (only needed for the local development server)
- A modern browser

## Run locally
1. Extract the project ZIP.
2. Open a terminal in the `jjk_battlegrounds` folder.
3. Run:

   ```bash
   npx serve .
   ```

4. Open the local URL printed by the command (usually `http://localhost:3000`).
5. On a phone, connect the phone and computer to the same Wi-Fi and open the server's LAN address, if your server displays one.

No npm dependencies or build step are required. For a quick test, you can also open `index.html` directly in a browser.

## Project structure
```text
jjk_battlegrounds/
├── index.html   # App layout and controls
├── styles.css   # Responsive visual design
├── game.js      # Character data, combat loop, meters and match state
└── README.md    # Setup and project notes
```

## Gameplay
- Pick Yuji, Gojo, Megumi or Todo.
- Strike and heavy attacks deal damage and build cursed energy / ultimate charge.
- The character ability consumes cursed energy.
- Ultimate becomes available at 100% charge.
- Domain Expansion is unlocked at 100% ultimate charge and empowers the next three attacks.
- The opponent counterattacks after player actions.
- Restart begins a fresh round.

## Controls
- Mobile: tap the on-screen action buttons.
- Desktop: `1` Strike, `2` Heavy, `3` Ability, `4` Ultimate.

## Architecture
- **Presentation:** `index.html` and `styles.css`.
- **Game state / rules:** `game.js` owns character selection, health, energy, cooldown-free turn timing, attacks, domain state, win/loss and restart.
- **Data-driven characters:** the `characters` array defines stats and technique labels; add new fighters there and extend ability logic if they need unique mechanics.

## Current prototype limitations
- Single-player versus a basic timed opponent; no online multiplayer or server authority.
- Fighter visuals are CSS placeholders, not animated 3D models.
- Techniques are represented by shared prototype damage rules rather than canon-accurate move systems.
- No account system, persistence, matchmaking, or production anti-cheat.
